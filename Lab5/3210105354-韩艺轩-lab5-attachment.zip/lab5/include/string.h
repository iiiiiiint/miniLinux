#pragma once

#include "types.h"

void* memset(void *, int, uint64);
void *memcpy(void *dst, void *src, unsigned long n);
