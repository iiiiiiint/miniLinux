#include "printk.h"
#include "defs.h"

// Please do not modify

void test() {
    printk("kernel is running!\n");
    while (1);
}
